package com.cg.pizzaorder.bean;

public enum VegToppings{
  Capsicum,
  Mushroom,
 Jalapeno,
 Paneer;
}
